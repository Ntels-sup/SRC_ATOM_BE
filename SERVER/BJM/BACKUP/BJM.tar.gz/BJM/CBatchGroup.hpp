#ifndef __CBATCHGROUP_HPP__
#define __CBATCHGROUP_HPP__

#include "BJM_Define.hpp"
#include <list>
#include <map>

#define BJ_BATCH_GROUP_LAST "999999"

class CBatchGroup
{

public:

    CBatchGroup();
    ~CBatchGroup();

    bool    				Init(DB * a_pDB);
	int						LoadGroupInfo(ST_BatchGroup  *a_batchGroups);
	int						GroupUpdate();
	int						GroupDelete();
	int						GroupInsert();

private:
	DB * 					m_pDB;

};

#endif // __CBATCHGROUP_HPP__
