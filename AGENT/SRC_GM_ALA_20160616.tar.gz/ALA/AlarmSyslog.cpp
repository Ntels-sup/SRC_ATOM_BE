#include "AlarmSyslog.hpp"

#include "AlarmDataDef.hpp"

AlarmSyslog::AlarmSyslog() 
{
	m_mapGroupCode[0] = std::string( "Unknown" );
	m_mapGroupCode[1] = std::string( "Communication" );
	m_mapGroupCode[2] = std::string( "Processing Error" );
	m_mapGroupCode[3] = std::string( "Environmental" );
	m_mapGroupCode[4] = std::string( "Quality of Service" );
	m_mapGroupCode[5] = std::string( "Equipment" );
	m_mapGroupCode[6] = std::string( "Threshold Crossing Alert" );
	m_mapGroupCode[7] = std::string( "Etc" );
}


AlarmSyslog::~AlarmSyslog()
{
}


void AlarmSyslog::
SendSyslog( ST_AlarmEventMsg & _stAlarmEventMsg )
{
	int		nLogLevel = LOG_DEBUG;
	std::string	strMessage;

	setlogmask (LOG_UPTO (LOG_NOTICE));

	openlog ( "TEST_PROCESS", LOG_CONS | LOG_PID | LOG_NDELAY, LOG_LOCAL1);

	//ex) Jun 16 14:32:25 GM ./a.out[31829]: Program started by User 1001
	
	if( _stAlarmEventMsg.event_type_id_ == ALM::eALARM )
	{
		nLogLevel = LOG_CRIT;
	}
	else if( _stAlarmEventMsg.event_type_id_ == ALM::eFAULT )
	{
		nLogLevel = LOG_WARNING;
	}
	else
	{
		nLogLevel = LOG_NOTICE;
	}

	//strMessage = std::to_string( _stAlarmEventMsg.event_group_id_ );
	strMessage = m_mapGroupCode[ _stAlarmEventMsg.event_group_id_ ];
	strMessage.append( std::string(" ") );
	strMessage.append( _stAlarmEventMsg.probable_cause_ );
	strMessage.append( std::string(" ") );
	strMessage.append( _stAlarmEventMsg.location_ );
	strMessage.append( std::string(" ") );
	strMessage.append( _stAlarmEventMsg.value_ );

	syslog (nLogLevel, strMessage.c_str() );

	closelog ();

	/*
	body["message"]         =   _stAlarmEventMsg.message_;
	body["node_seq_id"]     =   _stAlarmEventMsg.sequence_id_;

	body["node_no"]         =   _stAlarmEventMsg.node_no_;
	body["node_name"]       =   _stAlarmEventMsg.node_name_;
	body["proc_no"]         =   _stAlarmEventMsg.proc_no_;
	body["severity_id"]     =   _stAlarmEventMsg.severity_id_;

	body["pkg_name"]        =   _stAlarmEventMsg.pkg_name_;
	body["event_type_id"]   =   _stAlarmEventMsg.event_type_id_;
	body["event_group_id"]  =   _stAlarmEventMsg.event_group_id_;
	body["code"]            =   _stAlarmEventMsg.code_;
	body["alias_code"]      =   _stAlarmEventMsg.alias_code_;
	body["probable_cause"]  =   _stAlarmEventMsg.probable_cause_;
	body["additional_text"] =   _stAlarmEventMsg.additional_text_;
	body["location"]        =   _stAlarmEventMsg.location_;
	body["target"]          =   _stAlarmEventMsg.target_;
	body["complement"]      =   _stAlarmEventMsg.complement_;
	body["value"]           =   _stAlarmEventMsg.value_;
	body["node_version"]    =   _stAlarmEventMsg.node_version_;
	body["node_type"]       =   _stAlarmEventMsg.node_type_;
	body["prc_date"]        =   _stAlarmEventMsg.prc_date_;
	body["dst_yn"]          =   _stAlarmEventMsg.dst_yn_;
	body["vnfm_yn"]         =   _stAlarmEventMsg.vnfm_yn_;
	*/

}
