
#ifndef __ALARM_SYSLOG_HPP__
#define __ALARM_SYSLOG_HPP__

#include <string>
#include <unordered_map>
#include "AlarmDataDef.hpp"

#include <syslog.h>

class AlarmSyslog
{
public:
    static void SendSyslog( ST_AlarmEventMsg & _stAlarmEventMsg );

    static std::unordered_map<int, std::string>      m_mapGroupCode;
    //static std::unordered_map<int, std::string>      m_mapSeverityCode;

private:
    explicit AlarmSyslog	();
    ~AlarmSyslog		();
};

#endif // __ALARM_SYSLOG_HPP__
